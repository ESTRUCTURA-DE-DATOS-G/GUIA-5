package LOGICA;

public class DocenteVO {
    
    private String nombreDocente, apellidoDocente, direccionDocente, carreraDocente;
    private int codigoDocente, telefonoDocente;

    public DocenteVO(String nombreDocente, String apellidoDocente, String direccionDocente, String carreraDocente, int codigoDocente, int telefonoDocente) {
        this.nombreDocente = nombreDocente;
        this.apellidoDocente = apellidoDocente;
        this.direccionDocente = direccionDocente;
        this.carreraDocente = carreraDocente;
        this.codigoDocente = codigoDocente;
        this.telefonoDocente = telefonoDocente;
    }
    
    public DocenteVO(){
        
    }
        
    public String getNombreDocente() {
        return nombreDocente;
    }

    public void setNombreDocente(String nombreDocente) {
        this.nombreDocente = nombreDocente;
    }

    public String getApellidoDocente() {
        return apellidoDocente;
    }

    public void setApellidoDocente(String apellidoDocente) {
        this.apellidoDocente = apellidoDocente;
    }

    public String getDireccionDocente() {
        return direccionDocente;
    }

    public void setDireccionDocente(String direccionDocente) {
        this.direccionDocente = direccionDocente;
    }

    public String getCarreraDocente() {
        return carreraDocente;
    }

    public void setCarreraDocente(String carreraDocente) {
        this.carreraDocente = carreraDocente;
    }

    public int getCodigoDocente() {
        return codigoDocente;
    }

    public void setCodigoDocente(int codigoDocente) {
        this.codigoDocente = codigoDocente;
    }

    public int getTelefonoDocente() {
        return telefonoDocente;
    }

    public void setTelefonoDocente(int telefonoDocente) {
        this.telefonoDocente = telefonoDocente;
    }


}
