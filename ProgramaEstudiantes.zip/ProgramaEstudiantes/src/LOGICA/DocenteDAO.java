
package LOGICA;
import GUI.ModificarDocente;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.JOptionPane;

public class DocenteDAO {
    private HashMap<Integer, DocenteVO> infoDocentes;

    public HashMap<Integer, DocenteVO> getInfoDocentes() {
        return infoDocentes;
    }

    public void setInfoDocentes(HashMap<Integer, DocenteVO> infoDocentes)
    {
        this.infoDocentes = infoDocentes;
    }

    public DocenteDAO(HashMap<Integer, DocenteVO> infoDocentes) {
        this.infoDocentes = infoDocentes;
    }

    public DocenteDAO() {
        this.infoDocentes = new HashMap<>();
    }

    public void crearDocente(DocenteVO docenteVO) {
        if (infoDocentes.containsKey(docenteVO.getCodigoDocente()) == false) {
            infoDocentes.put(docenteVO.getCodigoDocente(), docenteVO);
            JOptionPane.showMessageDialog(null, "DOCENTE REGISTRADO CORRECTAMENTE",
                    "Resgistrar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO ya se encuentra registrado, ingrese uno diferente",
                    "ERROR", 0);
        }
    }

    public void eliminarDocente(int codigo) {
        if (infoDocentes.containsKey(codigo) == true) {
            infoDocentes.remove(codigo);
            JOptionPane.showMessageDialog(null, "Se elimino correctamente", "Eliminar Docente.", 1);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.", "Eliminar Docente", 0);
        }

    }

    public void modificarDocente(int codigo, DocenteDAO docenteDAO) {

        if (infoDocentes.containsKey(codigo) == true) {
            ModificarDocente ventana = new ModificarDocente(codigo, getInfoDocentes(), docenteDAO);
            ventana.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.",
                    "ERROR", 0);

        }
        
    }
    
    public void actualizarDocente(DocenteVO docenteVO){
        infoDocentes.replace(docenteVO.getCodigoDocente(), docenteVO);
        JOptionPane.showMessageDialog(null, "Se actualizo correctamente.", "Actualizar Docente", 1);
    }
        
}
