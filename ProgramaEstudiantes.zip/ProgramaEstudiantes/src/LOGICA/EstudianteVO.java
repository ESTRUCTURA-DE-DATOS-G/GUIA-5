
package LOGICA;

public class EstudianteVO {
    
    private String nombreEstudiante, apellidoEstudiante, direccionEstudiante, carreraEstudiante;
    private int codigoEstudiante, telefonoEstudiante;

    public EstudianteVO(String nombreEstudiante, String apellidoEstudiante, String direccionEstudiante, String carreraEstudiante, int codigoEstudiante, int telefonoEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
        this.apellidoEstudiante = apellidoEstudiante;
        this.direccionEstudiante = direccionEstudiante;
        this.carreraEstudiante = carreraEstudiante;
        this.codigoEstudiante = codigoEstudiante;
        this.telefonoEstudiante = telefonoEstudiante;
        
    }
    
    public EstudianteVO(){
    
    }
    
    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public String getApellidoEstudiante() {
        return apellidoEstudiante;
    }

    public void setApellidoEstudiante(String apellidoEstudiante) {
        this.apellidoEstudiante = apellidoEstudiante;
    }

    public String getDireccionEstudiante() {
        return direccionEstudiante;
    }

    public void setDireccionEstudiante(String direccionEstudiante) {
        this.direccionEstudiante = direccionEstudiante;
    }

    public String getCarreraEstudiante() {
        return carreraEstudiante;
    }

    public void setCarreraEstudiante(String carreraEstudiante) {
        this.carreraEstudiante = carreraEstudiante;
    }

    public int getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(int codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public int getTelefonoEstudiante() {
        return telefonoEstudiante;
    }

    public void setTelefonoEstudiante(int telefonoEstudiante) {
        this.telefonoEstudiante = telefonoEstudiante;
    }
}
