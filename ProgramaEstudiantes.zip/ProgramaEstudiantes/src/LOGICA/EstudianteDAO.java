package LOGICA;

import GUI.ModificarEstudiante;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.JOptionPane;

public class EstudianteDAO {

    private HashMap<Integer, EstudianteVO> infoEstudiantes;

    public HashMap<Integer, EstudianteVO> getInfoEstudiantes() {
        return infoEstudiantes;
    }

    public void setInfoEstudiantes(HashMap<Integer, EstudianteVO> infoEstudiantes)
    {
        this.infoEstudiantes = infoEstudiantes;
    }

    public EstudianteDAO(HashMap<Integer, EstudianteVO> infoEstudiantes) {
        this.infoEstudiantes = infoEstudiantes;
    }

    public EstudianteDAO() {
        this.infoEstudiantes = new HashMap<>();
    }

    public void crearEstudiante(EstudianteVO estudianteVO) {
        if (infoEstudiantes.containsKey(estudianteVO.getCodigoEstudiante()) == false) {
            infoEstudiantes.put(estudianteVO.getCodigoEstudiante(), estudianteVO);
            JOptionPane.showMessageDialog(null, "ESTUDIANTE REGISTRADO CORRECTAMENTE",
                    "Resgistrar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO ya se encuentra registrado, ingrese uno diferente",
                    "ERROR", 0);
        }
    }

    public void eliminarEstudiante(int codigo) {
        if (infoEstudiantes.containsKey(codigo) == true) {
            infoEstudiantes.remove(codigo);
            JOptionPane.showMessageDialog(null, "Se elimino correctamente", "Eliminar Estudiante.", 1);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.", "Eliminar Estudiante", 0);
        }

    }

    public void modificarEstudiante(int codigo, EstudianteDAO estudianteDAO) {

        if (infoEstudiantes.containsKey(codigo) == true) {
            ModificarEstudiante ventana = new ModificarEstudiante(codigo, getInfoEstudiantes(), estudianteDAO);
            ventana.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.",
                    "ERROR", 0);

        }
        
    }
    
    public void actualizarEstudiante(EstudianteVO estudianteVO){
        infoEstudiantes.replace(estudianteVO.getCodigoEstudiante(), estudianteVO);
        JOptionPane.showMessageDialog(null, "Se actualizo correctamente.", "Actualizar Estudiante", 1);
    }
    
}

