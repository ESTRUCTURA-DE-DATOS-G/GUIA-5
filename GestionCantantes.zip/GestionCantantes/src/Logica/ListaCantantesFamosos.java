package Logica;

import Interfaz.ModificarCantante;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;

public class ListaCantantesFamosos extends cantanteFamoso {

    private ArrayList<cantanteFamoso> listaCantante = new ArrayList<>();

    public List<cantanteFamoso> getListaCantante() {
        return listaCantante;
    }

    public void agregarCantante(cantanteFamoso CantanteFamoso) {
        boolean duplicado = false;

        Iterator<cantanteFamoso> iterator = listaCantante.iterator();

        while (iterator.hasNext()) {
            cantanteFamoso cantante = iterator.next();
            if (cantante.getNombre() != null && cantante.getNombre().equals(CantanteFamoso.getNombre())) {
                duplicado = true;
                break;
            }
        }

        if (!duplicado) {
            listaCantante.add(CantanteFamoso);
            JOptionPane.showMessageDialog(null, "Cantante registrado",
                    "AGREGAR", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este Cantante ya está agregado, digita otro o modifica el ya registrado",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void organizarLista(){
        
        //Se utiliza un comparator que es de collections.sort para comparar y poder ordenar
        Comparator<cantanteFamoso> comparador = new Comparator<cantanteFamoso>(){
            @Override
            public int compare(cantanteFamoso cantante1, cantanteFamoso cantante2) {
                //Se compara los totales de las ventas
                return Integer.compare(cantante2.getTotalVentas(), cantante1.getTotalVentas());
                //Para menor a mayor solo cambiar de orden
            }
        };
        
        //Ordenar la lista con el collections
        Collections.sort(listaCantante, comparador);
    }
    
    public void modificarCantante(String nombre, ListaCantantesFamosos listaCantantesFamosos){
        boolean encontrado = false;
        Iterator<cantanteFamoso> iterator = listaCantante.iterator();
        while(iterator.hasNext()){
            cantanteFamoso cantante = iterator.next();
            if(cantante.getNombre().equals(nombre)){
                ModificarCantante modify = new ModificarCantante(nombre, listaCantante, listaCantantesFamosos); 
                modify.setVisible(true);
                encontrado = true;
                break;
            }
        }
        if(!encontrado){
            JOptionPane.showMessageDialog(null, "El cantante no se encuentra registrado", "Modificar Cantante", 
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void actualizarCantante(cantanteFamoso CantanteActualizado){
 
        for(int i = 0; i < listaCantante.size(); i++){
            cantanteFamoso cantante = listaCantante.get(i);
            if(cantante.getNombre().equals(CantanteActualizado.getNombre())){
                listaCantante.set(i, CantanteActualizado);//Reemplaza el antiguo por el nuevo
                JOptionPane.showMessageDialog(null, "Cantante Atualizado",  "Actualizar Cantante", 
                        JOptionPane.INFORMATION_MESSAGE);
                return; //Termina el metodo
            }
        }
        //Si no se encuentra
        JOptionPane.showMessageDialog(null, "No se encuentra el cantante", "Actualizar Cantante",
                JOptionPane.ERROR_MESSAGE);
    }
    
    public void eliminarCantante(String nombre){
        boolean encontrado = false;
        Iterator<cantanteFamoso> iterator = listaCantante.iterator();
        while(iterator.hasNext()){
            cantanteFamoso cantante = iterator.next();
            if(cantante.getNombre().equals(nombre)){
                iterator.remove();//Eliminar al cantante de la lista
                encontrado = true;
                JOptionPane.showMessageDialog(null, "Cantante Eliminado", "Eliminar Cantante", 
                        JOptionPane.INFORMATION_MESSAGE);
                break;//Toca salir del bucle ya que funciona con iterator
            }
        }
        
        if(!encontrado){
            JOptionPane.showMessageDialog(null, "El cantante no se encuentra Registrado", "Eliminar Cantante", 
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
