package Logica;

import Interfaz.MenuGestion;

public class Test {

    public static void main(String[] args) {

        ListaCantantesFamosos listaCantantesFamosos = new ListaCantantesFamosos();
        listaCantantesFamosos.agregarCantante(new cantanteFamoso("Eminem", "Recovery", 1001000));
        listaCantantesFamosos.agregarCantante(new cantanteFamoso("Coldplay", "Parachutes", 7500000));
        
        MenuGestion menu = new MenuGestion(listaCantantesFamosos);
        menu.setVisible(true);
    }
}
