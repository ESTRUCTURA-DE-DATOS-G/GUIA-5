package Logica;

public class cantanteFamoso {
    private String nombre, discoMasVentas;
    private int totalVentas;

    public cantanteFamoso(String nombre, String discoMasVentas, int totalVentas) {
        this.nombre = nombre;
        this.discoMasVentas = discoMasVentas;
        this.totalVentas = totalVentas;
    }
    
    public cantanteFamoso(){
        this.nombre = "";
        this.discoMasVentas = "";
        this.totalVentas = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDiscoMasVentas() {
        return discoMasVentas;
    }

    public int getTotalVentas() {
        return totalVentas;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDiscoMasVentas(String discoMasVentas) {
        this.discoMasVentas = discoMasVentas;
    }

    public void setTotalVentas(int totalVentas) {
        this.totalVentas = totalVentas;
    } 
}
