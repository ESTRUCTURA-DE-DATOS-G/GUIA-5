package Interfaz;

import Logica.ListaCantantesFamosos;
import Logica.cantanteFamoso;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class MenuGestion extends javax.swing.JFrame {

    ListaCantantesFamosos listaCantantesFamosos;
    FondoPanel fondo = new FondoPanel();

    public MenuGestion(ListaCantantesFamosos lista) {
        this.setContentPane(fondo);
        initComponents();
        setIconImage(getIconImage());
        setLocationRelativeTo(this);
        listaCantantesFamosos = lista;
        llenarTabla(lista);
    }

    public void llenarTabla(ListaCantantesFamosos listaCantantesFamosos) {
        DefaultTableModel modelo = new DefaultTableModel(new String[]{"Nombre", "Disco+Vendido", "Total Venta"},
                0);

        Iterator<cantanteFamoso> iterator = listaCantantesFamosos.getListaCantante().iterator();

        while (iterator.hasNext()) {
            cantanteFamoso cantante = iterator.next();
            Object[] fila = {cantante.getNombre(), cantante.getDiscoMasVentas(), cantante.getTotalVentas()};
            modelo.addRow(fila);
        }
        tbl_cantante.setModel(modelo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSpinner1 = new javax.swing.JSpinner();
        btn_agregarCant = new javax.swing.JButton();
        btn_modificarCant = new javax.swing.JButton();
        btn_eliminarCant = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btn_mayorMenor = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_cantante = new javax.swing.JTable();
        btn_actualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SOUND+");

        btn_agregarCant.setBackground(new java.awt.Color(153, 0, 51));
        btn_agregarCant.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        btn_agregarCant.setForeground(new java.awt.Color(255, 255, 255));
        btn_agregarCant.setText("AGREGAR CANTANTE");
        btn_agregarCant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarCantActionPerformed(evt);
            }
        });

        btn_modificarCant.setBackground(new java.awt.Color(153, 0, 51));
        btn_modificarCant.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        btn_modificarCant.setForeground(new java.awt.Color(255, 255, 255));
        btn_modificarCant.setText("MODIFICAR CANTANTE");
        btn_modificarCant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarCantActionPerformed(evt);
            }
        });

        btn_eliminarCant.setBackground(new java.awt.Color(153, 0, 51));
        btn_eliminarCant.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        btn_eliminarCant.setForeground(new java.awt.Color(255, 255, 255));
        btn_eliminarCant.setText("ELIMINAR CANTANTE");
        btn_eliminarCant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarCantActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DISCOGRAFIA SOUND+");

        btn_mayorMenor.setBackground(new java.awt.Color(153, 0, 51));
        btn_mayorMenor.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        btn_mayorMenor.setForeground(new java.awt.Color(255, 255, 255));
        btn_mayorMenor.setText("LISTA ORDENADA");
        btn_mayorMenor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mayorMenorActionPerformed(evt);
            }
        });

        tbl_cantante.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbl_cantante);

        btn_actualizar.setBackground(new java.awt.Color(153, 0, 51));
        btn_actualizar.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        btn_actualizar.setForeground(new java.awt.Color(255, 255, 255));
        btn_actualizar.setText("ACTUALIZAR TABLA");
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_modificarCant, javax.swing.GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)
                            .addComponent(btn_agregarCant, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_eliminarCant, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btn_actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_mayorMenor, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(43, 43, 43))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(210, 210, 210))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_agregarCant, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_mayorMenor, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_actualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_eliminarCant, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_modificarCant, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_agregarCantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarCantActionPerformed
        AgregarCantante agregar = new AgregarCantante(listaCantantesFamosos);
        agregar.setVisible(true);
    }//GEN-LAST:event_btn_agregarCantActionPerformed

    private void btn_eliminarCantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarCantActionPerformed
        eliminarCantante();
    }//GEN-LAST:event_btn_eliminarCantActionPerformed

    private void btn_mayorMenorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mayorMenorActionPerformed
        listaCantantesFamosos.organizarLista();
        llenarTabla(listaCantantesFamosos);
    }//GEN-LAST:event_btn_mayorMenorActionPerformed

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        llenarTabla(listaCantantesFamosos);
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_modificarCantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarCantActionPerformed
        String nombre = (JOptionPane.showInputDialog(null, "Digite el NOMBRE del CANTANTE a modificar: ",
                "MODIFICAR CANTANTE", 1));
        listaCantantesFamosos.modificarCantante(nombre, listaCantantesFamosos);
    }//GEN-LAST:event_btn_modificarCantActionPerformed

    private void eliminarCantante() {
        String nombre = (JOptionPane.showInputDialog(null, "Digite el NOMBRE del CANTANTE a eliminar: ",
                "ELIMINAR CANTANTE", 1));
        listaCantantesFamosos.eliminarCantante(nombre);
        llenarTabla(listaCantantesFamosos);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_agregarCant;
    private javax.swing.JButton btn_eliminarCant;
    private javax.swing.JButton btn_mayorMenor;
    private javax.swing.JButton btn_modificarCant;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable tbl_cantante;
    // End of variables declaration//GEN-END:variables

    class FondoPanel extends JPanel {

        private Image imagen;

        @Override
        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/fondo.png")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);

            setOpaque(false);

            super.paint(g);

        }

    }
    //Icono JFrame

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/icono.jpeg"));
        return retValue;
    }

}
